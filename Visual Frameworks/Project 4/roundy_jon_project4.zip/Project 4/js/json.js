var json = {
	"task1": {
		"cats": ["Category List:", "Misc"],
		"taskname": ["My Task Name:", "Test 1"],
		"date": ["Date:", "2012-07-12"],
		"time": ["Time:", "12:00pm"],
		"urgent": ["Urgent:", "on"],
		"slider1": ["Estimated Time:", "12"],
		"textbox": ["Notes:", "This is a test"]
	},
	"task2": {
		"cats": ["Category List:", "Work"],
		"taskname": ["My Task Name:", "Test 2"],
		"date": ["Date:", "2012-07-12"],
		"time": ["Time:", "4:00pm"],
		"urgent": ["Urgent:", "false"],
		"slider1": ["Estimated Time:", "5"],
		"textbox": ["Notes:", "This is a test 2"]
	},
	"task3": {
		"cats": ["Category List:", "Personal"],
		"taskname": ["My Task Name:", "Test 3"],
		"date": ["Date:", "2018-07-12"],
		"time": ["Time:", "9:00pm"],
		"urgent": ["Urgent:", "no"],
		"slider1": ["Estimated Time:", "6"],
		"textbox": ["Notes:", "This is a test 3"]
	}
}